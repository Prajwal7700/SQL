-- queries/top_reports.sql
-- Useful queries for reports and analysis

-- 1. Current stock levels
SELECT p.ProductID, p.ProductName, p.Category, i.Quantity, p.ReorderLevel
FROM Products p
LEFT JOIN Inventory i ON p.ProductID = i.ProductID
ORDER BY i.Quantity DESC;

-- 2. Low stock items needing reorder
SELECT p.ProductID, p.ProductName, i.Quantity, p.ReorderLevel
FROM Products p
JOIN Inventory i ON p.ProductID = i.ProductID
WHERE i.Quantity <= p.ReorderLevel;

-- 3. Total sales by product (last 30 days)
SELECT p.ProductName, SUM(si.Quantity) AS TotalUnitsSold, SUM(si.LineTotal) AS TotalSales
FROM SaleItems si
JOIN Sales s ON si.SaleID = s.SaleID
JOIN Products p ON si.ProductID = p.ProductID
WHERE s.SaleDate >= DATEADD(day, -30, GETDATE())
GROUP BY p.ProductName
ORDER BY TotalSales DESC;

-- 4. Top suppliers by restock quantity
SELECT sup.SupplierName, SUM(r.Quantity) AS TotalRestocked
FROM Restock r
JOIN Suppliers sup ON r.SupplierID = sup.SupplierID
GROUP BY sup.SupplierName
ORDER BY TotalRestocked DESC;
