# Sales & Inventory Management System (SQL Server)

## Project Overview
A relational database project for tracking products, inventory levels, suppliers, and sales. It includes schema scripts, sample data, useful queries, and instructions to set up locally (SQL Server / Azure SQL / Docker).

## Contents
- `schema.sql` - DDL: tables, primary/foreign keys, indexes
- `seed_data.sql` - Sample INSERT statements for testing
- `sample_data/` - CSV files with example datasets (Products, Inventory, Sales, Suppliers)
- `queries/` - Useful SQL queries and reports
- `README.md` - This file
- `.gitignore` - Ignore local DB and temp files

## Quick Start (SQL Server)
1. Create a new database:
```sql
CREATE DATABASE SalesInventoryDB;
GO
USE SalesInventoryDB;
```
2. Run `schema.sql` to create tables.
3. Run `seed_data.sql` or bulk import the CSV files in `sample_data/`.
4. Run queries from the `queries/` folder to explore data and generate reports.

## Notes
- Designed for SQL Server but portable to other RDBMS with minimal changes.
- Suitable for a portfolio: add ER diagram screenshot and sample query outputs in the repo.

---
Author: Prajwal Gowda
