-- seed_data.sql
USE SalesInventoryDB;
GO

-- Sample Products
INSERT INTO Products (ProductName, Category, UnitPrice, ReorderLevel) VALUES
('Product A', 'Electronics', 50.00, 20),
('Product B', 'Electronics', 70.00, 15),
('Product C', 'Household', 40.00, 10),
('Product D', 'Household', 25.50, 30);

-- Sample Suppliers
INSERT INTO Suppliers (SupplierName, ContactName, Phone, Email) VALUES
('Alpha Supplies', 'Ramesh', '555-0100', 'alpha@example.com'),
('Beta Traders', 'Sita', '555-0110', 'beta@example.com');

-- Inventory
INSERT INTO Inventory (ProductID, Quantity) VALUES
(1, 150),
(2, 120),
(3, 200),
(4, 80);

-- Sales and SaleItems
INSERT INTO Sales (SaleDate, CustomerName, TotalAmount) VALUES
('2025-01-05', 'Customer X', 6000.00),
('2025-01-10', 'Customer Y', 3500.00);

INSERT INTO SaleItems (SaleID, ProductID, Quantity, UnitPrice) VALUES
(1, 1, 120, 50.00),
(1, 2, 30, 70.00),
(2, 3, 50, 40.00),
(2, 4, 20, 25.50);

-- Restock
INSERT INTO Restock (ProductID, SupplierID, RestockDate, Quantity, UnitCost) VALUES
(4, 1, '2025-01-02', 100, 20.00);
