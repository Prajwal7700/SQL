-- schema.sql
-- Sales & Inventory Management System (SQL Server)

-- PRODUCTS
CREATE TABLE Products (
    ProductID INT IDENTITY(1,1) PRIMARY KEY,
    ProductName VARCHAR(150) NOT NULL,
    Category VARCHAR(100),
    UnitPrice DECIMAL(10,2) NOT NULL,
    ReorderLevel INT DEFAULT 10
);

-- SUPPLIERS
CREATE TABLE Suppliers (
    SupplierID INT IDENTITY(1,1) PRIMARY KEY,
    SupplierName VARCHAR(150) NOT NULL,
    ContactName VARCHAR(100),
    Phone VARCHAR(50),
    Email VARCHAR(150)
);

-- INVENTORY
CREATE TABLE Inventory (
    InventoryID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL DEFAULT 0,
    LastUpdated DATE DEFAULT GETDATE(),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- SALES (header)
CREATE TABLE Sales (
    SaleID INT IDENTITY(1,1) PRIMARY KEY,
    SaleDate DATE NOT NULL DEFAULT GETDATE(),
    CustomerName VARCHAR(150),
    TotalAmount DECIMAL(12,2) NOT NULL
);

-- SALE ITEMS (line items)
CREATE TABLE SaleItems (
    SaleItemID INT IDENTITY(1,1) PRIMARY KEY,
    SaleID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(10,2) NOT NULL,
    LineTotal AS (Quantity * UnitPrice) PERSISTED,
    FOREIGN KEY (SaleID) REFERENCES Sales(SaleID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- RESTOCKING LOG (from suppliers)
CREATE TABLE Restock (
    RestockID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    SupplierID INT,
    RestockDate DATE NOT NULL DEFAULT GETDATE(),
    Quantity INT NOT NULL,
    UnitCost DECIMAL(10,2) NULL,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID)
);

-- Indexes for faster lookups
CREATE INDEX IDX_Inventory_Product ON Inventory(ProductID);
CREATE INDEX IDX_SaleItems_Product ON SaleItems(ProductID);
CREATE INDEX IDX_Sales_Date ON Sales(SaleDate);
